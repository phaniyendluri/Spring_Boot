package in.phaniit.web_mvc_embeded_database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebMvcEmbededDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
