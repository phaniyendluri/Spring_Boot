package in.phaniit.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCaseEmbeddedDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCaseEmbeddedDatabaseApplication.class, args);
	}

}
